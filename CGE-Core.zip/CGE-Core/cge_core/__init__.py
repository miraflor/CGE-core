"""
CGE-Core: A Pyomo-based CGE framework faithful to Hosoe et al. (2010).

Fork of PyCGE (Juan Fung & Charley Burtwistle, NIST) with bug fixes
and local solver support.
"""
from cge_core.engine import PyCGE

__version__ = '0.2.0'
__all__ = ['PyCGE']
