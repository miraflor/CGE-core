# -*- coding: utf-8 -*-
"""
Standard CGE Example (Hosoe Ch. 6) -- tariff and tax abolition experiments.

Runs the full CGE-Core workflow end to end:
    load -> instance -> drop redundant eqn -> calibrate -> sim -> shock -> solve -> compare

Requires a local NLP solver. Two options:
    * IPOPT executable on PATH  ->  solver name 'ipopt'
    * cyipopt + PyNumero        ->  solver name 'cyipopt'

The redundant market-clearing equation (Walras' law) MUST be dropped before
solving with IPOPT; see PyCGE.model_drop_redundant for the full explanation.
"""
import os
import copy
from pyomo.environ import value, prod

from cge_core.examples.stdcge_model_def import StdModelDef
from cge_core.engine import PyCGE

SOLVER = 'cyipopt'   # change to 'ipopt' if you have the executable on PATH


def build_calibrated():
    """Return a freshly calibrated base CGE object."""
    model = StdModelDef()
    cge = PyCGE(model)
    data_dir = os.path.join(os.path.dirname(__file__), '..', 'data',
                            'stdcge_data_dir')
    cge.model_data(data_dir)

    # Fix the numeraire (matches Hosoe stdcge.gms: pf.fx("LAB") = 1)
    cge.model_instance('pf', 'LAB')

    # Drop one redundant market-clearing equation (Walras' law) so the
    # square system has DOF = 0 and IPOPT can solve it. The labor market
    # is a natural choice since labor is the numeraire factor.
    cge.model_drop_redundant('eqpf', 'LAB')

    cge.model_calibrate(SOLVER)
    return cge


# ----------------------------------------------------------------------
# Experiment 1: abolish import tariffs
# ----------------------------------------------------------------------
print("\n=== EXPERIMENT 1: ABOLISH IMPORT TARIFFS ===")
cge1 = build_calibrated()
cge1.model_sim()                      # clone calibrated base -> sim
cge1.model_modify_sim('taum', 'BRD', 0)
cge1.model_modify_sim('taum', 'MLK', 0)
cge1.model_solve(SOLVER)
cge1.model_postprocess('compare', 'print')


# ----------------------------------------------------------------------
# Experiment 2: abolish production taxes
# ----------------------------------------------------------------------
print("\n=== EXPERIMENT 2: ABOLISH PRODUCTION TAXES ===")
cge2 = build_calibrated()
cge2.model_sim()
cge2.model_modify_sim('tauz', 'BRD', 0)
cge2.model_modify_sim('tauz', 'MLK', 0)
cge2.model_solve(SOLVER)
cge2.model_postprocess('compare', 'print')


# ----------------------------------------------------------------------
# Welfare comparison (Hicksian Equivalent Variation)
# ----------------------------------------------------------------------
def equivalent_variation(cge):
    """Hicksian EV: expenditure to reach the new utility at base prices.

    With Cobb-Douglas utility U = prod(Xp_i^alpha_i) and a unit price
    index at the base equilibrium, the expenditure function is linear in
    utility, so EV reduces to the difference in the utility aggregate
    evaluated through the base-price expenditure function.
    """
    denom = prod((value(cge.base.alpha[i])) ** value(cge.base.alpha[i])
                 for i in cge.base.i)
    ep0 = value(cge.base.obj) / denom
    ep1 = value(cge.sim.obj) / denom
    return ep1 - ep0


print("\n=== WELFARE (Hicksian Equivalent Variation) ===")
print("Abolish tariffs:          EV = %+.4f" % equivalent_variation(cge1))
print("Abolish production taxes: EV = %+.4f" % equivalent_variation(cge2))
