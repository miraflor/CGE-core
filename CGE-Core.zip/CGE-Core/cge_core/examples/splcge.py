# -*- coding: utf-8 -*-
"""
Simple CGE Example (Hosoe Ch. 3-4) -- closed economy base calibration.

Demonstrates the minimal CGE-Core workflow:
    load -> instance -> drop redundant eqn -> calibrate -> inspect

Requires a local NLP solver ('cyipopt' or 'ipopt').
"""
import os
from pyomo.environ import value

from cge_core.examples.splcge_model_def import SplModelDef
from cge_core.engine import PyCGE

SOLVER = 'cyipopt'   # change to 'ipopt' if you have the executable on PATH

model = SplModelDef()
cge = PyCGE(model)
data_dir = os.path.join(os.path.dirname(__file__), '..', 'data',
                        'splcge_data_dir')
cge.model_data(data_dir)

# Fix numeraire
cge.model_instance('pf', 'LAB')

# Drop one redundant market-clearing equation (Walras' law) -> DOF = 0.
# See PyCGE.model_drop_redundant for the full explanation.
cge.model_drop_redundant('eqpf', 'LAB')

cge.model_calibrate(SOLVER)

print("\n=== BASE EQUILIBRIUM ===")
for i in cge.base.i:
    print("  Z[%s]  = %7.4f" % (i, value(cge.base.Z[i])))
for i in cge.base.i:
    print("  X[%s]  = %7.4f" % (i, value(cge.base.X[i])))
print("  Utility = %7.4f" % value(cge.base.obj))
