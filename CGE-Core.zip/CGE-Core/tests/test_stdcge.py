# -*- coding: utf-8 -*-
"""
Regression and correctness tests for the standard CGE model (Hosoe Ch. 6).

These tests encode the properties that must hold for the model to be a
faithful, correctly-solving implementation of Hosoe's stdcge:

  1. The abstract model builds and a concrete instance can be created.
  2. The assembled system is over-determined by exactly one equation
     (Walras' law) before the redundant equation is dropped.
  3. After dropping one market-clearing equation the system is square.
  4. The base case calibrates to the SAM-consistent equilibrium.
  5. The solver recovers that equilibrium from a perturbed starting point
     (i.e. it is genuinely solving, not echoing initial values).
  6. The dropped market clears automatically at the solution (Walras' law).
  7. Abolishing import tariffs raises welfare (the canonical Hosoe result).

A local NLP solver is required. The tests auto-detect 'ipopt' (executable)
or 'cyipopt' (PyNumero) and skip if neither is available.
"""
import os
import copy
import pytest

from pyomo.environ import value, Var, Constraint, SolverFactory

from cge_core.examples.stdcge_model_def import StdModelDef
from cge_core.engine import PyCGE


DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'cge_core',
                        'data', 'stdcge_data_dir')

# SAM-consistent base equilibrium (from Hosoe's standard SAM)
EXPECTED_BASE = {
    ('Z', 'BRD'): 73.0, ('Z', 'MLK'): 72.0,
    ('Xp', 'BRD'): 20.0, ('Xp', 'MLK'): 30.0,
    ('M', 'BRD'): 13.0, ('M', 'MLK'): 11.0,
    ('E', 'BRD'): 8.0,  ('E', 'MLK'): 4.0,
}


def _available_solver():
    for name in ('ipopt', 'cyipopt'):
        try:
            if SolverFactory(name).available(exception_flag=False):
                return name
        except Exception:
            continue
    return None


SOLVER = _available_solver()
requires_solver = pytest.mark.skipif(
    SOLVER is None, reason="no local NLP solver (ipopt/cyipopt) available")


def _fresh_instance(drop_redundant=True):
    cge = PyCGE(StdModelDef())
    cge.model_data(DATA_DIR)
    cge.model_instance('pf', 'LAB')
    if drop_redundant:
        cge.model_drop_redundant('eqpf', 'LAB')
    return cge


# ----------------------------------------------------------------------
# Structural tests (no solver required)
# ----------------------------------------------------------------------
def test_instance_builds():
    cge = _fresh_instance(drop_redundant=False)
    assert cge.base is not None
    n_con = sum(len(c) for c in cge.base.component_objects(Constraint))
    assert n_con == 48          # 24 constraint blocks expand to 48 scalars


def test_overdetermined_before_drop():
    """Before dropping a redundant equation, DOF must be exactly -1."""
    cge = _fresh_instance(drop_redundant=False)
    b = cge.base
    free = sum(1 for v in b.component_data_objects(Var, active=True)
               if not v.fixed)
    con = sum(1 for _ in b.component_data_objects(Constraint, active=True))
    assert free - con == -1


def test_square_after_drop():
    """After dropping one market clearing, DOF must be 0."""
    cge = _fresh_instance(drop_redundant=True)
    b = cge.base
    free = sum(1 for v in b.component_data_objects(Var, active=True)
               if not v.fixed)
    con = sum(1 for _ in b.component_data_objects(Constraint, active=True))
    assert free - con == 0


# ----------------------------------------------------------------------
# Solver tests
# ----------------------------------------------------------------------
@requires_solver
def test_base_reproduces_sam():
    cge = _fresh_instance()
    cge.model_calibrate(SOLVER)
    for (var, idx), target in EXPECTED_BASE.items():
        got = value(getattr(cge.base, var)[idx])
        assert got == pytest.approx(target, abs=1e-4), \
            "%s[%s] = %r, expected %r" % (var, idx, got, target)


@requires_solver
def test_solver_recovers_from_perturbation():
    """Perturb all free vars +50%; solver must still recover the SAM."""
    cge = _fresh_instance()
    for v in cge.base.component_objects(Var, active=True):
        for i in v:
            if v[i].value is not None and not v[i].fixed:
                v[i].value = v[i].value * 1.5
    cge.model_calibrate(SOLVER)
    for (var, idx), target in EXPECTED_BASE.items():
        got = value(getattr(cge.base, var)[idx])
        assert got == pytest.approx(target, abs=1e-3), \
            "%s[%s] = %r, expected %r" % (var, idx, got, target)


@requires_solver
def test_walras_dropped_market_clears():
    """The deactivated labor market must clear automatically at solution."""
    cge = _fresh_instance()
    cge.model_calibrate(SOLVER)
    b = cge.base
    supply = value(b.FF['LAB'])
    demand = sum(value(b.F['LAB', i]) for i in b.i)
    assert demand == pytest.approx(supply, abs=1e-6)


@requires_solver
def test_tariff_abolition_raises_welfare():
    cge = _fresh_instance()
    cge.model_calibrate(SOLVER)
    u_base = value(cge.base.obj)

    sim = copy.deepcopy(cge.base)
    sim.taum['BRD'] = 0
    sim.taum['MLK'] = 0
    SolverFactory(SOLVER).solve(sim)
    u_sim = value(sim.obj)

    assert u_sim > u_base        # removing distortion improves welfare
